#   15-112: Principles of Programming and Computer Science
#   Final Project: Fake OS (OS emulator)
#   Name      : Omar Sinan
#   AndrewID  : osinan

#   File Created: October 31, 2017
#   Modification History:
#   Start               End
#   31/10 07:00 pm      31/10 09:30 pm
#   01/11 01:00 pm      01/11 02:40 pm
#   02/11 09:00 pm      02/11 09:40 pm
#   03/11 09:00 am      03/11 11:30 am
#   03/11 04:00 pm      03/11 04:50 pm
#   07/11 10:30 am      07/11 01:20 pm
#   etc...

from Tkinter import *
import os
import hashlib
import widgets # my own library - custom widgets
import json # to encode lists to strings
import ast # to return strings back to lists
import __future__ # used in calculator app to check if there is 0 division
import math
import random # used to place mines in minesweeper randomly
from PIL import ImageTk, Image # to add pictures
import datetime # to get the time
import threading # to update the time

# main - the main class is the backbone of the application, it contains everything
# that is needed throughout the whole application (e.g. user directory, open applications,
# all the files, etc..)
class main():
    def __init__(self):
        # application's width and height
        self.WINDOW_WIDTH = 800
        self.WINDOW_HEIGHT = 600

        self.BAR_HEIGHT = 30

        # current logged in user
        self.user = ""
        self.users_directory = os.path.dirname(os.path.realpath(__file__)) + "/Users"

        # notice that stores the string to be shown when you hover
        self.messageNotice = None

        self.files = []
        self.openApplications = []
        self.folderFrames = []

    # makes the menubar and startmenu
    def create(self):
        self.bar = menuBar(mainFrame)
        self.menu = startMenu(mainFrame)

    def toggleMenu(self):
        self.menu.toggle()

    # loads all the files from the user directory
    def loadFiles(self):
        unacceptable = ["hash", ".DS_Store"]
        self.files = []
        files = os.listdir(self.users_directory + "/" + self.user)
        files.sort(key=lambda x: os.path.getmtime(self.users_directory + "/" + self.user + "/" + x))
        if len(files) > 0:
            for index, mfile in enumerate(files):
                canAdd = True
                for word in unacceptable:
                    if word in mfile:
                        canAdd = False
                if canAdd:
                    self.files.append(mfile)

    # show the files in the desktop
    def showFiles(self):
        startX = 20
        startY = 20

        for i in range(len(self.folderFrames)):
            folder = self.folderFrames[0]
            # destroy icon
            folder.keys()[0].destroy()
            # destroy label
            folder.values()[0][1].destroy()
            self.folderFrames.remove(folder)

        self.folder_dim = 50
        self.imageFiles = ["ntpd.png", "pnt.png"]
        self.images = {}
        for img in self.imageFiles:
            ico = Image.open(img).convert("RGB")
            ico = ico.resize((self.folder_dim, self.folder_dim), Image.ANTIALIAS)
            ico = ImageTk.PhotoImage(ico)
            self.images[img.split('.')[0]] = ico

        for file in self.files:

            split_name = file.split('.')
            useImage = self.images.get(split_name[len(split_name) - 1], None)
            if useImage != None:
                fileFrame = Label(mainFrame, image=useImage, highlightcolor="black", highlightthickness=0, bd=0)
                fileFrame.img = useImage

            fileFrame.place(x=startX, y=startY)
            myText = (file[0:10] + ' ...') if len(file) > 10 else file
            fileLabel = Label(mainFrame, text=myText, bg="black", fg="white", wraplength=50)
            fileLabel.place(x=startX, y=startY + self.folder_dim + 5)

            self.folderFrames.append({fileFrame:[file, fileLabel]})

            fileFrame.bind("<Enter>", lambda event, coord=(startX + self.folder_dim/2, startY + self.folder_dim + 10), text=file: self.displayMessage(event, coord, text))
            fileFrame.bind("<Leave>", self.removeMessage)

            fileFrame.bind("<Double-Button-1>", lambda event, myfile=file: self.openFile(event, myfile))

            startY += self.folder_dim + 55

            if startY > 470:
                startY = 20
                startX += self.folder_dim + 40

    # shows the message when u hover over files
    def displayMessage(self, e, coord, text):
        if self.messageNotice == None:
            self.messageNotice = Label(mainFrame, text=text, wraplength=100, bg="yellow")
            self.messageNotice.place(x=coord[0], y=coord[1])

    def removeMessage(self, e):
        if self.messageNotice != None:
            self.messageNotice.destroy()
            self.messageNotice = None

    def openFile(self, e, myfile):
        ext = myfile.split(".")
        ext = ext[len(ext) - 1]
        for format in formats:
            if format == ext:
                openFile = open(self.users_directory + "/" + self.user + "/" + myfile)
                mywindow = eval(formats[format])(content=openFile.read(), title=myfile)

# this class is for the startup (i.e. the login screen and register screen
class startup():
    def __init__(self):
        # path of users directory
        self.users_directory = os.path.dirname(os.path.realpath(__file__)) + "/Users"
        print self.users_directory
        self.usersScreen()

    # the screen that shows up when you first run the program with the user and password input
    def usersScreen(self, e=None):
        self.usersFrame = Frame(mainFrame, width=WIDTH, height=HEIGHT, bg="#7C84F7")
        self.usersFrame.place(x=0, y=0)

        # Window object - the frame with a blue top bar that holds the entries
        self.loginWnd = Window(App="Login", fileName=None, options=None, appObject=self, isApp=False, canClose=False, hasToolBar=False, width=300, height=200)

        # light blue frame with the copyright label
        jumboFrame = Frame(self.loginWnd.contentFrame, width=self.loginWnd.width, height=60, bg="#A1BDEC")
        jumboFrame.place(x=0, y=0)

        # label that shows any errors
        self.errorNotice = Label(jumboFrame, text="", bg="#A1BDEC", fg="red", width=37)
        self.errorNotice.place(x=0, y=10)

        cred = Label(jumboFrame, text=u"\u00a9 2017 Omar Sinan", bg="#A1BDEC", font=("Helvetica", 10))
        cred.place(x=0, y=40)

        # frame that holds everything under the jumboFrame
        mloginFrame = Frame(self.loginWnd.contentFrame, width=self.loginWnd.width, height=self.loginWnd.height-60)
        mloginFrame.place(x=0, y=60)

        usernameLabel = Label(mloginFrame, text="User name:", font=("Helvetica", 16))
        usernameLabel.place(x=10, y=20)
        self.usernameEntry = Entry(mloginFrame)
        self.usernameEntry.place(x=120, y=20)

        passwordLabel = Label(mloginFrame, text="Password:", font=("Helvetica", 16))
        passwordLabel.place(x=10, y=50)
        self.passwordEntry = Entry(mloginFrame, show="*")
        self.passwordEntry.place(x=120, y=50)

        # login button using widgets library
        logBtn = widgets.wButton(parent=mloginFrame, width=70, height=20, x=self.loginWnd.width - 143, y=90, bg="#bfbfbf", text="Login", func=self.checkLogin)
        logBtn.f.config(bd=1, highlightthickness=1, highlightcolor="black", highlightbackground="black", relief=RAISED)

        # register button using widgets library
        regBtn = widgets.wButton(parent=mloginFrame, width=70, height=20, x=self.loginWnd.width - 65, y=90, bg="#bfbfbf", text="Register", func=self.registerUser)
        regBtn.f.config(bd=1, highlightthickness=1, highlightcolor="black", highlightbackground="black", relief=RAISED)

    # register user when the register button is clicked
    def registerUser(self, e):
        # get the username and password
        user = self.usernameEntry.get()
        password = self.passwordEntry.get()

        # basic error checking - can't be empty
        if len(user) == 0 or len(password) == 0:
            self.errorNotice.config(text="Field left blank")
            return

        # if the users directory doesn't exist then create one
        if not os.path.exists(self.users_directory):
            os.makedirs(self.users_directory)
        if not os.path.exists(self.users_directory + "/" + self.usernameEntry.get()):
            # make a directory for the user and store in it a file called hash.os2 that has the password hash
            os.makedirs(self.users_directory + "/" + self.usernameEntry.get())
            mypass = open(self.users_directory + "/" + self.usernameEntry.get() + "/hash.os2", "w")
            hash = hashlib.md5(self.passwordEntry.get()).hexdigest()
            mypass.write(hash)
            mypass.close()
            self.checkLogin()
        else:
            self.errorNotice.config(text="User already exists")

    # checks login details when the login button is clicked
    def checkLogin(self, e=None):
        # gets the username and password
        user = self.usernameEntry.get()
        password = self.passwordEntry.get()

        # basic error checking - can't be empty
        if len(user) == 0 or len(password) == 0:
            self.errorNotice.config(text="Field left blank")
            return

        # compute the hash using hashlib and check it against the stored hash
        # if its correct then load user files and show desktop
        hash = hashlib.md5(password).hexdigest()
        fileOpen = open(self.users_directory + "/" + user + "/hash.os2")
        readAll = fileOpen.read()
        if readAll.strip() == hash:
            self.usersFrame.destroy()
            self.loginWnd.closeWindow()
            global mainObject
            mainObject = main()
            mainObject.user = user
            mainObject.create()
            mainObject.loadFiles()
            mainObject.showFiles()
        else:
            self.errorNotice.config(text="Wrong password")

# the start menu with all the applications
class startMenu():
    def __init__(self, parent):
        self.main = mainObject
        self.parent = parent

        self.visible = False

        self.menu_width = 250
        self.menu_height = 300

        self.programs = {
            "Notepad":1,
            "Paint":2,
            "Calculator":3,
            "Minesweeper": 4,
        }

    # runs when the red shutdown button is pressed
    def shutdown(self, e):
        # cancels the thread, destroys the root and quits
        mainObject.bar.thread.cancel()
        root.destroy()
        root.quit()

    # runs when the yellow log off button is pressed
    def logout(self, e):
        # for every open application, destroy the application and update openApplications list
        for i in range(len(mainObject.openApplications)):
            mainObject.openApplications[0].window.borderFrame.destroy()
            mainObject.openApplications.remove(mainObject.openApplications[0])

        # for every icon in the desktop, destroy it and update the folderFrames list
        for i in range(len(mainObject.folderFrames)):
            folder = mainObject.folderFrames[0]
            # destroy icon
            folder.keys()[0].destroy()
            # destroy label
            folder.values()[0][1].destroy()
            mainObject.folderFrames.remove(folder)

        mainObject.bar.thread.cancel()
        mainObject.bar.bar.destroy()
        self.toggle()
        mainObjectStart = startup()

    # bar at the top of the start menu with the user's name
    def topBar(self):
        self.topBar_height = 50
        self.topFrame = Frame(self.start_menu, width=self.menu_width, height=self.topBar_height, bg="#2962D4")
        self.topFrame.place(x=0, y=0)

        usernameTitle = Label(self.topFrame, text=mainObject.user, bg="#2962D4", fg="white", font=('Helvetica', 20))
        usernameTitle.place(x=20, y=13)

    # bar at the side of the start menu with the shutdown and log off buttons
    def sideBar(self):
        self.sideFrame_width = 50
        self.sideFrame = Frame(self.start_menu, width=self.sideFrame_width, height=self.menu_height - self.topBar_height, bg="#D6E5F9")
        self.sideFrame.place(x=self.menu_width-self.sideFrame_width, y=self.topBar_height)

        shutdown_dim = 30

        self.shutdown_btn = Frame(self.sideFrame, width=shutdown_dim, height=shutdown_dim, bg="#DFB043")
        self.shutdown_btn.place(x=(self.sideFrame_width - shutdown_dim) / 2, y=self.menu_height - shutdown_dim - self.topBar_height - 20 - shutdown_dim)
        self.shutdown_btn.bind("<Button-1>", self.logout)

        self.shutdown_btn = Frame(self.sideFrame, width=shutdown_dim, height=shutdown_dim, bg="#D24F25")
        self.shutdown_btn.place(x=(self.sideFrame_width-shutdown_dim)/2, y=self.menu_height-shutdown_dim-self.topBar_height-10)
        self.shutdown_btn.bind("<Button-1>", self.shutdown)

    # bar in the center with the 4 programs
    def mainBar(self):
        self.mainFrame_width = self.menu_width-self.sideFrame_width
        self.mainFrame = Frame(self.start_menu, width=self.mainFrame_width, height=self.menu_height - self.topBar_height, bg="white")
        self.mainFrame.place(x=0, y=self.topBar_height)

        self.programFrame_height = 50
        self.programPictures = ["pnt.png", "clcltr.png", "ntpd.png", "mnswpr.png"]

        # for every program in self.programs, create a parent frame and place it appropriately
        for i in range(len(self.programs.keys())):
            self.programFrame = Frame(self.mainFrame, width=self.mainFrame_width, height=self.programFrame_height, bg="white")
            self.programFrame.place(x=0, y=10 + (i*self.programFrame_height) + (i * 10))

            # load and place the picture icon for the program
            programPicture_dim = self.programFrame_height - 10

            ico = Image.open(self.programPictures[i])
            # resize the picture
            ico = ico.resize((programPicture_dim, programPicture_dim), Image.ANTIALIAS)
            ico = ImageTk.PhotoImage(ico)
            # attach the picture to a label
            programPicture = Label(self.programFrame, image=ico, highlightcolor="white", bg="white", highlightthickness=0, bd=0)
            programPicture.img = ico

            programPicture.place(x=5, y=(self.programFrame_height - programPicture_dim)/2)

            programTitle = Label(self.programFrame, text=self.programs.keys()[i])
            programTitle.place(x=programPicture_dim + 15, y=self.programFrame_height/2 - 12)

            self.programFrame.bind("<Button-1>", lambda event, app=self.programs.keys()[i]: self.openProgram(event, app))
            programPicture.bind("<Button-1>", lambda event, app=self.programs.keys()[i]: self.openProgram(event, app))
            programTitle.bind("<Button-1>", lambda event, app=self.programs.keys()[i]: self.openProgram(event, app))

    # runs when a program is clicked from the start menu
    def openProgram(self, e, App):
        print "Opening",App
        # if App=Notepad, it will create a Notepad object by using eval so it isn't treated as a string
        window = eval(App)()
        self.toggle()

    # runs whenever the start button is pressed
    def toggle(self):
        if not self.visible:
            self.start_menu = Frame(self.parent, width=self.menu_width, height=self.menu_height, bg="green")
            self.start_menu.place(x=0, y=HEIGHT - self.menu_height - self.main.BAR_HEIGHT)
            self.topBar()
            self.sideBar()
            self.mainBar()
        else:
            self.start_menu.destroy()
        self.visible = not self.visible

# the menu bar that holds the start button (coming soon: applications stack)
class menuBar():
    def __init__(self, parent):
        self.main = mainObject
        self.parent = parent
        self.messageNotice = None
        self.x = 75
        self.y = 3
        self.count = 0

        # array that keeps track of apps in the stack in the taskbar
        self.stackApps = []

        # start menu
        self.bar = Frame(self.parent, width=WIDTH, height=self.main.BAR_HEIGHT, bg="#2962D4")
        self.bar.place(x=0, y=HEIGHT - self.main.BAR_HEIGHT)

        # start button
        self.dim = (70, self.main.BAR_HEIGHT)
        x = self.dim[0]/2
        y = self.dim[1]/2
        startBtn = widgets.wButton(parent=self.bar, width=self.dim[0], height=self.dim[1], x=x, y=y, bg="#458E32", func=self.openStartMenu, text="start", ht=0, font=("Helvetica", 20), fg="white")

        # time label - bottom right
        timeFrame_dim = (100, self.main.BAR_HEIGHT)
        timeFrame = Frame(self.bar, width=timeFrame_dim[0], height=timeFrame_dim[1], bg="#3F9FEB")
        timeFrame.place(x=WIDTH - timeFrame_dim[0], y=0)

        time = datetime.datetime.now().strftime('%I:%M %p')
        timeExtended = datetime.datetime.now().strftime('%d/%m/%Y %I:%M %p')
        timeX = timeFrame_dim[0]/2
        timeY = timeFrame_dim[1]/2
        self.timeLabel = widgets.wButton(parent=timeFrame, width=timeFrame_dim[0], height=timeFrame_dim[1], x=timeX, y=timeY, bg="#3F9FEB", text=time, ht=0, fg="white", anchor=CENTER)
        self.timeLabel.label.bind("<Enter>", lambda event, coord=(WIDTH-93, HEIGHT-65), text=timeExtended: self.displayMessage(event, coord, text))
        self.timeLabel.label.bind("<Leave>", self.removeMessage)

        self.updateTime()

    def updateTime(self):
        # runs every minute to update time
        print 'wot'
        self.timeLabel.label.config(text=datetime.datetime.now().strftime('%I:%M %p'))
        self.thread = threading.Timer(60.0, self.updateTime)
        self.thread.start()

    # shows the message when u hover over time
    def displayMessage(self, e, coord, text):
        if self.messageNotice == None:
            self.messageNotice = Label(mainFrame, text=text, wraplength=100, bg="yellow")
            self.messageNotice.place(x=coord[0], y=coord[1])

    # removes the message when you aren't hovering over the time
    def removeMessage(self, e):
        if self.messageNotice != None:
            self.messageNotice.destroy()
            self.messageNotice = None

    # user clicked on start button
    def openStartMenu(self, e):
        self.main.toggleMenu()

    # updates application stack when user opens and closes applications
    def updateStack(self):

        # reset everything by deleting
        for i in self.stackApps:
            i.destroy()

        for i in range(len(self.stackApps)):
            self.stackApps.remove(self.stackApps[0])

        apps = mainObject.openApplications
        self.x = 75
        self.y = 3
        self.count = 0
        # add everything back with the updated openApplications
        for applic in apps:
            print applic
            self.addApplication(applic.window)

    # adds an individual application to the stack at the bottom
    def addApplication(self, applic):
        # creates a frame and ensures that there are less that 5 items in there already
        stackFrame = Frame(mainObject.bar.bar, width=120, height=25, bg="#3F9FEB")
        stackFrame.config(relief=RAISED, bd=1)
        if self.count < 5:
            stackFrame.place(x=self.x, y=self.y)

        # load the respective image icon
        if applic.app == "Notepad":
            ico = Image.open("ntpd.png")
        elif applic.app == "Paint":
            ico = Image.open("pnt.png")
        elif applic.app == "Calculator":
            ico = Image.open("clcltr.png")
        elif applic.app == "Minesweeper":
            ico = Image.open("mnswpr.png")
        # resize the image
        ico = ico.resize((20, 20), Image.ANTIALIAS)
        ico = ImageTk.PhotoImage(ico)
        # attach the image to the label
        programPicture = Label(stackFrame, image=ico, highlightcolor="#3F9FEB", bg="#3F9FEB", highlightthickness=0, bd=0)
        programPicture.img = ico
        if self.count < 5:
            programPicture.place(x=12, y=11, anchor=CENTER)
        stackFrame.bind('<Button-1>', applic.borderFrame.tkraise())
        programPicture.bind('<Button-1>', applic.borderFrame.tkraise())

        txt = applic.fileName if applic.fileName != None else applic.app
        programName = Label(stackFrame, text=txt, fg="white", bg="#3F9FEB")
        if self.count < 5:
            programName.place(x=25, y=0)

        stackFrame.bind("<Button-1>", lambda x: applic.borderFrame.tkraise())
        programPicture.bind("<Button-1>", lambda x: applic.borderFrame.tkraise())
        programName.bind("<Button-1>", lambda x: applic.borderFrame.tkraise())

        self.stackApps.append(stackFrame)
        self.x += 125
        self.count += 1

# window class which is the general template for an application window
class Window():
    def __init__(self, width=500, height=400, App=None, fileName=None, options=None, appObject=None, isApp=True, canClose=True, hasToolBar=True):
        self.width = width
        self.height = height
        self.app = App
        self.fileName = fileName
        self.appObject = appObject
        self.options = options
        self.isApp = isApp

        self.open_dropdowns = []

        self.borderWidth = 2

        # this is the main frame for the Window object, if destroyed, the whole window gets destroyed
        self.borderFrame = Frame(mainFrame, width=self.width + self.borderWidth, height=self.height + self.borderWidth, bg="black")
        self.borderFrame.place(x=(WIDTH - self.width + self.borderWidth)/2, y=(HEIGHT - self.height + self.borderWidth)/2)

        self.frame = Frame(self.borderFrame, width=self.width, height=self.height)
        self.frame.place(x=self.borderWidth/2, y=self.borderWidth/2)

        # blue topbar with the filename
        self.topBar_height = 30
        self.topBar = Frame(self.frame, width=self.width, height=self.topBar_height, bg="blue")
        self.topBar.place(x=0, y=0)

        # can only drag the application if isApp is true, otherwise you can't drag it
        if isApp:
            self.topBar.bind("<ButtonPress-1>", self.startMove)
            self.topBar.bind("<ButtonRelease-1>", self.stopMove)
            self.topBar.bind("<B1-Motion>", self.onMotion)

            mainObject.openApplications.append(self.appObject)

        # if a fileName is passed when created the object, add it to the title
        # otherwise just use the application's name
        if fileName != None:
            self.title = Label(self.topBar, text=App + " - " + fileName, bg="blue", foreground="white")
        else:
            self.title = Label(self.topBar, text=App, bg="blue", foreground="white")
        self.title.place(x=5, y=(self.topBar_height - (self.topBar_height - 10))/2)

        # if canClose is true, there will be a red button to close the application that calls the
        # closeWindow function
        if canClose:
            self.close = Frame(self.topBar, width=self.topBar_height - 10, height=self.topBar_height - 10, bg="red")
            self.close.place(x=self.width - (self.topBar_height - 5), y=(self.topBar_height - (self.topBar_height - 10))/2)
            self.close.bind("<Button-1>", self.closeWindow)

        # if hasToolbar is true, it will have the grey toolbar with the dropdown menus
        if hasToolBar:
            self.statusBar_height = 25
            self.statusBar = Frame(self.frame, width=self.width, height=self.statusBar_height, bg="grey")
            self.statusBar.place(x=0, y=self.topBar_height)
        else:
            self.statusBar_height = 0

        # frame that contains the content of the application
        self.contentFrame_height = self.height - self.topBar_height - self.statusBar_height
        self.contentFrame = Frame(self.frame, width=self.width, height=self.contentFrame_height)
        self.contentFrame.place(x=0, y=self.topBar_height+self.statusBar_height)

        # adds the labels in the grey status bar
        if self.options != None:
            for i in range(len(self.options)):
                if type(self.options[i]) is dict:
                    # drop down menu
                    key = self.options[i].keys()[0]
                    menu_item = Label(self.statusBar, width=7, text=key, bg="grey")
                    menu_item.place(x=i*60, y=0)
                    dropdown_start_position = self.topBar_height + self.statusBar_height
                    menu_item.bind("<Button-1>", lambda event, coord=(i*60, dropdown_start_position), key=key, items=self.options[i][key]: self.toggleDropdown(event, coord, key, items))
                else:
                    # normal single button
                    Label(self.statusBar, width=7, text=self.options[i], bg="grey").place(x=i*60, y=0)

    # Dragging windows functionality adapted from StackOverflow (startMove, stopMove, onMotion):
    # https://stackoverflow.com/questions/4055267/python-tkinter-mouse-drag-a-window-without-borders-eg-overridedirect1
    # Modified the code a little to suite my needs (i.e. last line of onMotion)

    # START OF ADAPTED CODE

    def startMove(self, event):
        # START ADAPTED CODE FOR startMove #
        self.x, self.y = event.x, event.y
        # END ADAPTED CODE FOR startMove #

        self.borderFrame.tkraise()

        for applic in mainObject.openApplications:
            if applic.App == "Paint":
                applic.fileContent = json.dumps([[applic.canvas.itemcget(item, 'tags')] + applic.canvas.coords(item) + [applic.canvas.itemcget(item, 'fill')] + [applic.canvas.itemcget(item, 'width')] for item in applic.items])
                applic.canvas.delete(ALL)
                applic.items[:] = []
                applic.toolkit.destroy()
            elif applic.App == "Notepad":
                applic.content = applic.textEntry.get(1.0, END)
                applic.textEntry.delete(1.0, END)
            elif applic.App == "Calculator":
                applic.removeButtons()
            elif applic.App == "Minesweeper":
                self.MSGrid = applic.grid
                for i in range(applic.cols):
                    for j in range(applic.rows):
                        applic.grid[i][j].btn.destroy()

    def stopMove(self, event):
        # START ADAPTED CODE FOR stopMove #
        self.x, self.y = None, None
        # END ADAPTED CODE FOR stopMove #

        for applic in mainObject.openApplications:
            if applic.App == "Paint":
                applic.insertContent(applic.fileContent)
                applic.createToolkit()
            elif applic.App == "Notepad":
                applic.textEntry.insert(INSERT, applic.content)
            elif applic.App == "Calculator":
                applic.addButtons()
            elif applic.App == "Minesweeper":
                applic.showGrid(grid=self.MSGrid)


    def onMotion(self, event):
        # START ADAPTED CODE FOR onMotion #
        deltax = event.x - self.x
        deltay = event.y - self.y
        x = self.borderFrame.winfo_x() + deltax
        y = self.borderFrame.winfo_y() + deltay
        # END ADAPTED CODE FOR onMotion #

        self.borderFrame.place(x=x, y=y)

    # END OF ADAPTED CODE

    # runs when the red button is pressed
    def closeWindow(self, e=None):
        self.borderFrame.destroy()
        if self.isApp:
            for applic in mainObject.openApplications:
                if applic == self.appObject:
                    mainObject.openApplications.remove(applic)
            mainObject.bar.updateStack()

    # runs when an item in the grey status bar is clicked to reveal a dropdown menu
    def toggleDropdown(self, e, coord, key, items):
        self.foundOpenDropdown = False
        for dropdown in self.open_dropdowns:
            if dropdown.keys()[0] == key:
                # menu already open, just close
                self.foundOpenDropdown = True
            dropdown[dropdown.keys()[0]].destroy()
            self.open_dropdowns.remove(dropdown)
        if not self.foundOpenDropdown:
            dropdown_dim = 100
            dropdown = Frame(self.frame, width=dropdown_dim, height=dropdown_dim, bg="grey")
            dropdown.place(x=coord[0], y=coord[1])
            self.open_dropdowns.append({key:dropdown})

            for index, item in enumerate(items):
                item_label = Label(dropdown, text=item, bg="grey")
                item_label.place(x=0, y=20*index)
                content = None
                if self.app == "Notepad":
                    content = self.appObject.textEntry.get("1.0", END)
                elif self.app == "Paint":
                    content = [[self.appObject.canvas.itemcget(canvasItem, 'tags')] + self.appObject.canvas.coords(canvasItem) + [self.appObject.canvas.itemcget(canvasItem, 'fill')] + [self.appObject.canvas.itemcget(canvasItem, 'width')] for canvasItem in self.appObject.items]
                elif self.app == "Minesweeper":
                    content = None
                item_label.bind("<Button-1>", lambda event, dropdown=dropdown, window=self, filename=self.fileName, content=content: items[item](event, dropdown, window, filename, content))

# notepad application
class Notepad():
    def __init__(self, content=None, title=None):
        # SAMPLE USAGE OF TOP BAR
        '''self.statusBarOptions = [
            {"File":
                 {"Save": self.saveFile,
                  "Open": self.saveFile}
             },
            "About",
            "Test",
            {"Options":
                 {"Save": self.saveFile}
             },
        ]'''

        self.statusBarOptions = [
            {"File":
                 {"Save": self.saveFile,}
                 # "Open": self.saveFile}
             }
        ]

        self.App = "Notepad"
        self.title = "Untitled" if title == None else title
        self.window = Window(App=self.App, fileName=self.title, options=self.statusBarOptions, appObject=self)

        mainObject.bar.updateStack()

        self.mainFrame_height = self.window.height-self.window.topBar_height-self.window.statusBar_height
        self.mainFrame = Frame(self.window.frame, width=self.window.width, height=self.mainFrame_height)
        self.mainFrame.place(x=0, y=self.window.topBar_height+self.window.statusBar_height)
        self.textEntry = Text(self.mainFrame, width=72, height=28, wrap="word", borderwidth=0, highlightcolor="white")
        self.textEntry.place(x=0, y=0)

        self.content = ""

        if content != None:
            self.textEntry.insert(INSERT, content)
            self.content = content

    # save file frame with entry
    def saveFile(self, e, dropdown, window, filename, content):

        for i in window.open_dropdowns:
            window.open_dropdowns.remove(i)
        dropdown.destroy()

        if not os.path.exists(mainObject.users_directory + "/" + mainObject.user + "/" + filename):
            saveFrame_width, saveFrame_height = 200, 140
            self.saveFrame = Frame(window.frame, width=200, height=140, bg="grey")
            self.saveFrame.place(x=window.width/2, y=window.height/2, anchor="center")

            self.saveLabel = Label(self.saveFrame, text="Save File", bg="grey", font=('Helvetica', 22)).place(x=10, y=10)

            self.fileNameLabel = Label(self.saveFrame, text="File Name:", bg="grey", font=('Helvetica', 14)).place(x=25, y=50)
            self.fileNameEntry = Entry(self.saveFrame, highlightthickness=1, highlightcolor="black")
            self.fileNameEntry.place(x=saveFrame_width/2, y= 80, anchor="center")

            btn_width, btn_height = 50, 25
            x = saveFrame_width/2
            y = 110
            saveBtn = widgets.wButton(parent=self.saveFrame, width=btn_width, height=btn_height, x=x, y=y, bg="orange",func=lambda event, window=window, content=content: self.saveFileToDir(event, window, self.fileNameEntry.get(), content, False), text="Save")
        else:
            self.saveFileToDir(None, window, filename, content, True)

    # save the file to the directory
    def saveFileToDir(self, e, window, filename, content, alreadyExists):
        if len(filename) > 0:
            if alreadyExists:
                new_file = open(mainObject.users_directory + "/" + mainObject.user + "/" + filename, "w")
            else:
                new_file = open(mainObject.users_directory + "/" + mainObject.user + "/" + filename + ".ntpd", "w")

            new_file.write(content)
            new_file.close()

            mainObject.loadFiles()
            mainObject.showFiles()

            self.window.borderFrame.tkraise()

            window.title.destroy()
            if alreadyExists:
                window.title = Label(window.topBar, text=window.app + " - " + filename, bg="blue", foreground="white")
            else:
                window.title = Label(window.topBar, text=window.app + " - " + filename + ".ntpd", bg="blue",foreground="white")
            window.title.place(x=5, y=(window.topBar_height - (window.topBar_height - 10)) / 2)

            # if file does not already exist, it means saveFrame was shown to input file name
            if not alreadyExists:
                self.saveFrame.destroy()


# calculator application
class Calculator():
    def __init__(self, content=None, title=None):
        self.App = "Calculator"
        self.title = None
        self.window = Window(App=self.App, fileName=self.title, appObject=self, width=230, height=345, hasToolBar=False)

        mainObject.bar.updateStack()

        self.mainFrame_height = self.window.height - self.window.topBar_height - self.window.statusBar_height
        self.mainFrame = Frame(self.window.contentFrame, width=self.window.width, height=self.mainFrame_height)
        self.mainFrame.place(x=0, y=0)

        self.display = Frame(self.mainFrame, width=self.window.width, height=78, bg="#323232")
        self.display.place(x=0, y=0)

        self.displayText = Label(self.display, width=18, height=3, text="", justify=RIGHT, anchor=E, font=('Helvetica', 20), fg="white", bg="#323232", padx=10, wraplength=self.window.width - 20)
        self.displayText.place(x=6, y=5)

        self.btn_dim = (58, 48)
        self.btns = ['AC', 'DEL', '%', '/', '7', '8', '9', '*', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '=']

        self.inError = False
        self.allButtons = []

        self.addButtons()

    # when a button in the calculator is pressed
    def btnClick(self, event, key):
        unacceptable = ["=", "AC", "DEL"]
        if self.inError:
            self.displayText.config(text="")
            self.inError = False

        if key not in unacceptable:
            self.displayText.config(text=self.displayText.cget('text') + key)
        else:
            if key == "=":
                if len(self.displayText.cget('text')) > 0:
                    try:
                        result = eval(compile(self.displayText.cget('text').strip(), '<string>', 'eval', __future__.division.compiler_flag))
                    except SyntaxError:
                        result = "Syntax Error"
                        self.inError = True
                    except ZeroDivisionError:
                        result = "Math Error"
                        self.inError = True

                    self.displayText.config(text=str(result))
            elif key == "AC":
                self.displayText.config(text="")
            elif key == "DEL":
                self.displayText.config(text=self.displayText.cget('text')[:len(self.displayText.cget('text')) - 1])

    # remove all buttons when dragging window
    def removeButtons(self):
        for btn in self.allButtons:
            btn.f.destroy()

    # add all buttons to the calculator
    def addButtons(self):
        x = self.btn_dim[0] / 2
        y = 101
        count = 0
        for i, btn in enumerate(self.btns):
            w = self.btn_dim[0] if btn != '0' else self.btn_dim[0] * 2
            mins = self.btn_dim[0] / 2 if btn == '0' else 0
            bg = "orange" if x == 203 else "#bfbfbf"
            if count == 4:
                x = w / 2
                y += self.btn_dim[1]
                count = 0
            btn = widgets.wButton(parent=self.mainFrame, width=w, height=self.btn_dim[1], x=x, y=y, bg=bg, text=btn, func=lambda event, key=btn: self.btnClick(event, key))
            btn.f.config(bd=1, highlightthickness=1, highlightcolor="black", highlightbackground="black", relief=RAISED)
            count += 1
            x += w - mins

            self.allButtons.append(btn)

# paint application
class Paint():
    def __init__(self, content=None, title=None):
        self.statusBarOptions = [
            {"File":
                 {"Save": self.saveFile}
             }
        ]

        self.App = "Paint"
        self.title = "Untitled" if title == None else title
        self.window = Window(App=self.App, fileName=self.title, options=self.statusBarOptions, appObject=self)

        mainObject.bar.updateStack()

        self.toolkit_height = 55

        # MODES
        self.paintMode = True
        self.squareMode = False
        self.circleMode = False

        self.selectedColor = "black"
        self.selectedWidth = 2

        self.canvas_height = self.window.height - self.window.topBar_height - self.window.statusBar_height - self.toolkit_height
        self.canvas = Canvas(self.window.contentFrame, width=self.window.width, height=self.canvas_height, bg="white", highlightthickness=0)
        self.canvas.place(x=0, y=0)

        # creates tools at the bottom with colors, widths, sames and mode buttons
        self.createToolkit()

        self.old_x = None
        self.old_y = None

        self.canvas.bind('<Button-1>', self.button_down)
        self.canvas.bind('<B1-Motion>', self.paint)
        self.canvas.bind('<ButtonRelease-1>', self.button_up)

        self.items = []
        self.currentDragItem = None
        self.fileContent = content

        self.insertContent(self.fileContent)

    # creates the toolkit
    def createToolkit(self):
        self.toolkit = Frame(self.window.contentFrame, width=self.window.width, height=self.toolkit_height, bg="grey")
        self.toolkit.place(x=0, y=self.canvas_height)

        # pre-set colors
        colors = ["black", "blue", "red", "yellow", "green", "purple", "orange", "gold", "tomato", "maroon", "navy", "cyan", "lime green", "coral"]
        self.colorBtns = []
        y = 5
        x = 5

        # create brush button
        squareFrame = Frame(self.toolkit, width=20, height=20, bg="white")
        squareFrame.place(x=x, y=y)
        ico = Image.open("brush.png")
        ico = ico.resize((16, 16), Image.ANTIALIAS)
        ico = ImageTk.PhotoImage(ico)
        programPicture = Label(squareFrame, image=ico, highlightcolor="white", bg="white", highlightthickness=0, bd=0)
        programPicture.img = ico
        programPicture.place(x=10, y=10, anchor=CENTER)
        squareFrame.bind('<Button-1>', self.setPaintMode)
        programPicture.bind('<Button-1>', self.setPaintMode)

        y += 25

        # create delete button
        squareFrame = Frame(self.toolkit, width=20, height=20, bg="white")
        squareFrame.place(x=x, y=y)
        ico = Image.open("eraser.png")
        ico = ico.resize((16, 16), Image.ANTIALIAS)
        ico = ImageTk.PhotoImage(ico)
        programPicture = Label(squareFrame, image=ico, highlightcolor="white", bg="white", highlightthickness=0, bd=0)
        programPicture.img = ico
        programPicture.place(x=10, y=10, anchor=CENTER)
        squareFrame.bind('<Button-1>', self.setDeleteMode)
        programPicture.bind('<Button-1>', self.setDeleteMode)

        y = 5
        x += 25

        for index, color in enumerate(colors):
            if index > 6 and y < 25:
                y += 25
                x = 30
            cFrame = Frame(self.toolkit, width=20, height=20, bg=color)
            cFrame.place(x=x, y=y)
            cFrame.bind("<Button-1>", lambda event, col=cFrame: self.selectColor(event, col))
            self.colorBtns.append(cFrame)
            x += 25

        self.selectColor(col="black")

        widths = [2, 5, 7]
        x += 5
        y = 5

        widths_height = 13

        for index, width in enumerate(widths):
            wFrame = Frame(self.toolkit, width=30, height=widths_height, bg="white")
            wFrame.place(x=x, y=y)
            visFrame = Frame(wFrame, width=20, height=width, bg="black")
            visFrame.place(x=15, y=widths_height / 2, anchor="center")

            func = lambda event, wid=width: self.changeWidth(event, wid)
            wFrame.bind('<Button-1>', func)
            visFrame.bind('<Button-1>', func)

            y += widths_height + 3

        x += 40
        y = 5

        # create a square button
        squareFrame = Frame(self.toolkit, width=20, height=20, bg="white")
        squareFrame.place(x=x, y=y)
        visFrame = Frame(squareFrame, width=14, height=14, bg="black")
        visFrame.place(x=10, y=10, anchor="center")

        squareFrame.bind('<Button-1>', self.setSquareMode)
        visFrame.bind('<Button-1>', self.setSquareMode)

        y += 25

        # create a circle button
        squareFrame = Frame(self.toolkit, width=20, height=20, bg="white")
        squareFrame.place(x=x, y=y)
        ico = Image.open("circle.png").convert("RGBA")
        ico = ico.resize((16, 16), Image.ANTIALIAS)
        ico = ImageTk.PhotoImage(ico)
        programPicture = Label(squareFrame, image=ico, highlightcolor="white", bg="white", highlightthickness=0, bd=0)
        programPicture.img = ico
        programPicture.place(x=10, y=10, anchor=CENTER)
        squareFrame.bind('<Button-1>', self.setCircleMode)
        programPicture.bind('<Button-1>', self.setCircleMode)

    # eraser clicked
    def setDeleteMode(self, e):
        self.paintMode = True
        self.squareMode, self.circleMode = False, False
        self.selectedColor = "white"

    # brush clicked
    def setPaintMode(self, e):
        self.paintMode = True
        self.squareMode, self.circleMode = False, False

    # square shape icon clicked
    def setSquareMode(self, e):
        self.squareMode = True
        self.paintMode, self.circleMode = False, False

    # ellipse shape icon clicked
    def setCircleMode(self, e):
        self.circleMode = True
        self.paintMode, self.squareMode = False, False

    # width icon clicked
    def changeWidth(self, e, wid):
        self.selectedWidth = wid

    # if mouse down and motion on canvas, draw specified mode
    def paint(self, event):
        if self.squareMode:
            self.canvas.coords(self.currentDragItem, self.x, self.y, event.x, event.y)
        if self.circleMode:
            self.canvas.coords(self.currentDragItem, self.x, self.y, event.x, event.y)
        if self.old_x and self.old_y:
            if self.paintMode:
                newItem = self.canvas.create_line(self.old_x, self.old_y, event.x, event.y, width=self.selectedWidth, fill=self.selectedColor, capstyle=ROUND, smooth=TRUE, splinesteps=36, tags="line")
                self.items.append(newItem)
        self.old_x = event.x
        self.old_y = event.y

    # load the content of the file - when u open it up or when u drag the window
    def insertContent(self, content):
        if content != None:
            items = ast.literal_eval(content)

            for item in items:
                mcoords = [i for i in item]
                tag = mcoords[0]
                if tag == "line":
                    nItem = self.canvas.create_line([mcoords[1], mcoords[2], mcoords[3], mcoords[4]], fill=mcoords[5], width=mcoords[6], capstyle=ROUND, smooth=TRUE, splinesteps=36, tags="line")
                elif tag == "rect":
                    nItem = self.canvas.create_rectangle([mcoords[1], mcoords[2], mcoords[3], mcoords[4]], fill=mcoords[5], width=mcoords[6], tags="rect")
                elif tag == "oval":
                    nItem = self.canvas.create_oval([mcoords[1], mcoords[2], mcoords[3], mcoords[4]], fill=mcoords[5], width=mcoords[6], tags="oval")
                self.items.append(nItem)

    # when button is pressed, create a rect or oval depending on mode
    def button_down(self, event):
        self.x = event.x
        self.y = event.y
        if self.squareMode:
            rect = self.canvas.create_rectangle(self.x, self.y, self.x, self.y, fill=self.selectedColor, tags="rect")
            self.items.append(rect)
            self.currentDragItem = rect
        if self.circleMode:
            circ = self.canvas.create_oval(self.x, self.y, self.x, self.y, fill=self.selectedColor, tags="oval")
            self.items.append(circ)
            self.currentDragItem = circ

    # reset old_x and old_y
    def button_up(self, event):
        self.old_x, self.old_y = None, None

    # different color has been selected
    def selectColor(self, e=None, col=None):
        if e != None and col != None:
            if type(col) is str:
                self.selectedColor = col
            else:
                self.selectedColor = col.cget('bg')
        for color in self.colorBtns:
            color.config(highlightthickness=0)
            if color.cget('bg') == self.selectedColor:
                color.config(highlightthickness=1)

    # save file frame with entry
    def saveFile(self, e, dropdown, window, filename, content):

        for i in window.open_dropdowns:
            window.open_dropdowns.remove(i)
        dropdown.destroy()

        if not os.path.exists(mainObject.users_directory + "/" + mainObject.user + "/" + filename):
            saveFrame_width, saveFrame_height = 200, 140
            self.saveFrame = Frame(window.frame, width=200, height=140, bg="grey")
            self.saveFrame.place(x=window.width/2, y=window.height/2, anchor="center")

            self.saveLabel = Label(self.saveFrame, text="Save File", bg="grey", font=('Helvetica', 22)).place(x=10, y=10)

            self.fileNameLabel = Label(self.saveFrame, text="File Name:", bg="grey", font=('Helvetica', 14)).place(x=25, y=50)
            self.fileNameEntry = Entry(self.saveFrame, highlightthickness=1, highlightcolor="black")
            self.fileNameEntry.place(x=saveFrame_width/2, y= 80, anchor="center")

            btn_width, btn_height = 50, 25
            x = saveFrame_width/2
            y = 110
            saveBtn = widgets.wButton(parent=self.saveFrame, width=btn_width, height=btn_height, x=x, y=y, bg="orange",func=lambda event, window=window, content=content: self.saveFileToDir(event, window, self.fileNameEntry.get(), content, False), text="Save")
        else:
            self.saveFileToDir(None, window, filename, content, True)

    # save the file to the directory
    def saveFileToDir(self, e, window, filename, content, alreadyExists):
        if len(filename) > 0:
            if alreadyExists:
                new_file = open(mainObject.users_directory + "/" + mainObject.user + "/" + filename, "w")
            else:
                new_file = open(mainObject.users_directory + "/" + mainObject.user + "/" + filename + ".pnt", "w")

            new_file.write(json.dumps(content))
            new_file.close()

            mainObject.loadFiles()
            mainObject.showFiles()

            self.window.borderFrame.tkraise()

            window.title.destroy()
            if alreadyExists:
                window.title = Label(window.topBar, text=window.app + " - " + filename, bg="blue", foreground="white")
            else:
                window.title = Label(window.topBar, text=window.app + " - " + filename + ".ntpd", bg="blue", foreground="white")
            window.title.place(x=5, y=(window.topBar_height - (window.topBar_height - 10)) / 2)

            # if file does not already exist, it means saveFrame was shown to input file name
            if not alreadyExists:
                self.saveFrame.destroy()

class MSCell():
    def __init__(self, parent, i, j, w, grid):
        self.parent = parent
        self.i = i
        self.j = j
        self.w = w
        self.x = (i * w) + (w / 2)
        self.y = (j * w) + (w / 2)
        self.neighborCount = 0
        self.bee = False
        self.revealed = False
        self.grid = grid
        self.marked = False

    # show the cell with or without text
    def show(self, withText=False, bg="white", gameOver=False):
        if self.marked:
            bg = "red"
        elif self.revealed:
            bg = "#c8c8c8"
        else:
            bg = "white"
        fg = "black"

        if gameOver:
            if self.bee:
                text = u"\u2022"
                if self.marked:
                    fg = "black"
                else:
                    fg = "red"
            else:
                if self.neighborCount != 0:
                    text = self.neighborCount
                else:
                    text = ""
        else:
            if (withText or self.revealed) and self.neighborCount != 0 and not self.bee:
                text = self.neighborCount
            elif withText and self.bee:
                text = u"\u2022"
                if self.marked:
                    fg = "black"
                else:
                    fg = "red"
            else:
                text = ""

        func = lambda event, i=self.i, j=self.j: self.click(event, i, j)
        func2 = lambda event, i=self.i, j=self.j: self.markBomb(event, i, j)
        self.btn = widgets.wButton(parent=self.parent.mainFrame, width=self.w, height=self.w, x=self.x, y=self.y, bg=bg, fg=fg, func=func, func2=func2, text=text)

    # reveal the cell with default floodfill
    def reveal(self, flood=True):
        self.revealed = True
        self.btn.destroy()

        self.show(withText=True, bg="#c8c8c8")
        if flood:
            if self.neighborCount == 0:
                self.floodFill()

    # floodfill that recursively reveals cells which call floodFill again
    def floodFill(self):
        for xoff in range(-1, 2):
            for yoff in range(-1, 2):
                i = self.i + xoff
                j = self.j + yoff
                if i > -1 and i < self.parent.cols and j > -1 and j < self.parent.rows:
                    neighbor = self.parent.grid[i][j]
                    if not neighbor.bee and not neighbor.revealed:
                        neighbor.reveal()

    # count how many bees/mines a cell has
    def countBees(self):
        if self.bee:
            self.neighborCount = -1
            return

        total = 0
        for xoff in range(-1, 2):
            for yoff in range(-1, 2):
                i = self.i + xoff
                j = self.j + yoff
                if i > -1 and i < self.parent.cols and j > -1 and j < self.parent.rows:
                    neighbor = self.parent.grid[i][j]
                    if neighbor.bee:
                        total += 1

        self.neighborCount = total

    # when a cell is clicked
    def click(self, e, i, j):
        if self.bee:
            self.parent.gameOver()
            loseNotice = Window(App="Notice", fileName=None, options=None, appObject=self, isApp=False, hasToolBar=False, width=100, height=50)
            label = Label(loseNotice.contentFrame, text="You Lose!")
            label.pack(fill=BOTH, expand=1)
            return
        if not self.revealed:
            self.parent.grid[i][j].reveal()
        if self.parent.checkWin():
            winNotice = Window(App="Notice", fileName=None, options=None, appObject=self, isApp=False, hasToolBar=False, width=100, height=50)
            label = Label(winNotice.contentFrame, text="You Win!")
            label.pack(fill=BOTH, expand=1)

    # right clicked to mark a mine
    def markBomb(self, e, i, j):
        self.marked = not self.marked
        self.btn.destroy()
        self.show()
        if self.parent.checkWin():
            winNotice = Window(App="Notice", fileName=None, options=None, appObject=self, isApp=False, hasToolBar=False, width=100, height=50)
            label = Label(winNotice.contentFrame, text="You Win!")
            label.pack(fill=BOTH, expand=1)

# minesweeper application
class Minesweeper():
    def __init__(self, title=None):
        self.statusBarOptions = [
            {"File":
                 {"New game": self.restart}
             }
        ]

        self.App = "Minesweeper"
        self.title = None

        self.width = 200
        self.height = 255

        self.w = 20
        self.cols = int(math.floor(self.width / self.w))
        self.rows = int(math.floor((self.height - 55) / self.w))
        self.totalBees = 10
        self.gameOverBool = False

        self.window = Window(App=self.App, fileName=self.title, options=self.statusBarOptions, appObject=self, width=self.width, height=self.height)

        mainObject.bar.updateStack()

        self.mainFrame = Frame(self.window.contentFrame, width=self.width, height=self.height, bg="white")
        self.mainFrame.place(x=0, y=0)

        self.showGrid()
        self.putBees()

    # restart the game when new game is clicked
    def restart(self, e, dropdown, window, filename, content):
        for i in window.open_dropdowns:
            window.open_dropdowns.remove(i)
        dropdown.destroy()

        for i in range(self.cols):
            for j in range(self.rows):
                self.grid[i][j].btn.destroy()

        self.gameOverBool = False
        self.showGrid()
        self.putBees()

    # show the grid
    def showGrid(self, grid=None):
        if grid == None:
            self.grid = []
        else:
            self.grid = grid

        #print self.grid

        for i in range(self.cols):
            tmp = []
            for j in range(self.rows):
                tmp.append(MSCell(self, i, j, self.w, self.grid))
            self.grid.append(tmp)

        for i in range(self.cols):
            for j in range(self.rows):
                self.grid[i][j].show(gameOver=self.gameOverBool)

    # place bees randomly
    def putBees(self):
        options = []
        for i in range(self.cols):
            for j in range(self.rows):
                options.append([i, j])

        for n in range(self.totalBees):
            choice = random.choice(options)
            i = choice[0]
            j = choice[1]
            options.remove(choice)
            self.grid[i][j].bee = True

        for i in range(self.cols):
            for j in range(self.rows):
                self.grid[i][j].countBees()

    # gameover - reveal everything
    def gameOver(self):
        for i in range(self.cols):
            for j in range(self.rows):
                self.grid[i][j].reveal(flood=False)
        self.gameOverBool = True

    # check if the user won
    def checkWin(self):

        for i in range(self.cols):
            for j in range(self.rows):
                if self.grid[i][j].bee and not self.grid[i][j].marked:
                    return False

        for i in range(self.cols):
            for j in range(self.rows):
                if not self.grid[i][j].bee and self.grid[i][j].marked:
                    return False

        for i in range(self.cols):
            for j in range(self.rows):
                if not self.grid[i][j].bee:
                    if not self.grid[i][j].revealed:
                        return False

        return True


root = Tk()
WIDTH = 800
HEIGHT = 600
root.geometry('{}x{}'.format(WIDTH, HEIGHT))

# main frame
mainFrame = Frame(root, width=WIDTH, height=HEIGHT, bg="black")
mainFrame.pack()

mainObjectStart = startup()

mainObject = None
formats = {"ntpd":"Notepad", "pnt":"Paint"}

root.mainloop()